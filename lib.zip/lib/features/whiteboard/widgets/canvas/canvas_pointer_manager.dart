import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../models/board_element.dart';
import '../../models/stroke_element.dart';
import '../../state/whiteboard_provider.dart';

/// Manages multi-touch pointer state, palm rejection algorithms, gesture erasing,
/// native touch hint event channels, and watchdog cleanup timers for [WhiteboardCanvas].
class CanvasPointerManager {
  static final bool kDebugPointerInfo = false;

  static const double kPanelWidthMm = 1895.0; // 75" panel physical width in mm
  static const double kPalmRadiusMajorMin = 21.0;
  static const double kPalmSizeMin = 0.14;
  static const int kPalmClusterMinPoints = 3;
  static const double kPalmClusterRadiusMaxMm = 150.0;
  static const bool kTwoPointerRule = false;
  static const int kPointerFreshMs = 250;
  static const int kPointerStaleMs = 800;
  static const int kPruneThrottleMs = 40;
  static const int kWatchdogMs = 100;
  static const double kGestureMinMovePx = 2.0;
  static const int kPalmCancelTimeWindowMs = 300;
  static const double kStaticGestureEraserRadius = 60.0;

  final Map<int, BoardElement> activeElements = {};
  final Map<int, Offset> eraserPositions = {};
  final Map<int, Offset> lastEraserPositions = {};
  final Map<int, Offset> smoothedDeltas = {};
  final Map<int, Offset> tipOffsets = {};
  final Map<int, PointerEvent> pointers = {};
  final Map<int, DateTime> pointerDownTimes = {};
  final Map<int, DateTime> lastSeen = {};
  final Map<int, Map<String, dynamic>> nativeTouchHints = {};

  StreamSubscription? _touchHintSubscription;
  int cancelEventCount = 0;
  int prunedGhostCount = 0;
  int nativePointerCount = 0;
  String lastCancelInfo = 'None';
  DateTime? lastPalmSeen;
  DateTime _lastPrune = DateTime.fromMillisecondsSinceEpoch(0);

  /// pointerId -> mind-map target node
  final Map<int, ({String mmId, String nodeId})> mmStrokeTargets = {};
  int? panPointerId;

  Path? currentLasso;
  bool isUsingGestureEraser = false;

  // Gesture eraser centroid state
  Offset? gestureCenter;
  Offset? gestureLastCenter;
  Offset? pendingErase;
  bool _eraseScheduled = false;

  bool _pulseScheduled = false;
  Timer? watchdog;
  double screenWidth = 1920.0;
  RenderBox? box;

  DateTime lastMoveLogTime = DateTime.now();
  final ValueNotifier<int> activeLayerPulse = ValueNotifier(0);

  void init(BuildContext context) {
    screenWidth = MediaQuery.sizeOf(context).width;
    _listenNativeTouchHints();
  }

  void updateDependencies(BuildContext context) {
    screenWidth = MediaQuery.sizeOf(context).width;
  }

  void dispose() {
    watchdog?.cancel();
    _touchHintSubscription?.cancel();
    activeLayerPulse.dispose();
  }

  void _listenNativeTouchHints() {
    if (Platform.isAndroid) {
      try {
        const channel = EventChannel('com.pencilai.whiteboard/touch_hints');
        _touchHintSubscription = channel.receiveBroadcastStream().listen((event) {
          if (event is Map) {
            final cnt = event['pointerCount'] as int?;
            if (cnt != null) {
              nativePointerCount = cnt;
            }
            if (event.containsKey('pointers')) {
              final ptrs = event['pointers'] as List?;
              if (ptrs != null) {
                for (var p in ptrs) {
                  if (p is Map) {
                    final pid = p['pointerId'] as int?;
                    if (pid != null) {
                      nativeTouchHints[pid] = Map<String, dynamic>.from(p);
                    }
                  }
                }
              }
            }
          }
        }, onError: (_) {});
      } catch (_) {}
    }
  }

  double get pxPerMm => screenWidth / kPanelWidthMm;
  double get twoPointerPalmDistanceMaxPx => 50.0 * pxPerMm;
  double get palmClusterRadiusMaxPx => kPalmClusterRadiusMaxMm * pxPerMm;

  bool isTouchKind(PointerEvent e) => e.kind != PointerDeviceKind.stylus;

  bool hasTouchDown() => pointers.values.any(isTouchKind);

  void requestRepaint(bool mounted) {
    if (_pulseScheduled) return;
    _pulseScheduled = true;
    SchedulerBinding.instance.scheduleFrameCallback((_) {
      _pulseScheduled = false;
      if (mounted) activeLayerPulse.value++;
    });
  }

  List<PointerEvent> freshTouchPointers() {
    final now = DateTime.now();
    return pointers.values.where((e) {
      if (!isTouchKind(e)) return false;
      final lastTime = lastSeen[e.pointer];
      if (lastTime == null) return false;
      return now.difference(lastTime).inMilliseconds < kPointerFreshMs;
    }).toList();
  }

  void forgetPointer(int pid) {
    if (panPointerId == pid) {
      panPointerId = null;
    }
    mmStrokeTargets.remove(pid);
    pointers.remove(pid);
    eraserPositions.remove(pid);
    lastEraserPositions.remove(pid);
    pointerDownTimes.remove(pid);
    lastSeen.remove(pid);
    nativeTouchHints.remove(pid);
    smoothedDeltas.remove(pid);
    tipOffsets.remove(pid);
    final active = activeElements.remove(pid);
    if (active is StrokeElement) {
      active.disposeLive();
    }
  }

  void pruneStalePointers({bool force = false}) {
    final now = DateTime.now();
    if (!force && now.difference(_lastPrune).inMilliseconds < kPruneThrottleMs) return;
    _lastPrune = now;

    final toRemove = <int>[];
    for (var entry in lastSeen.entries) {
      if (now.difference(entry.value).inMilliseconds > kPointerStaleMs) {
        toRemove.add(entry.key);
      }
    }
    for (var pid in toRemove) {
      forgetPointer(pid);
      prunedGhostCount++;
    }

    if (nativePointerCount > 0) {
      final nonStylusPointers = pointers.entries.where((e) => isTouchKind(e.value)).toList();
      if (nonStylusPointers.length > nativePointerCount) {
        nonStylusPointers.sort((a, b) {
          final timeA = lastSeen[a.key] ?? DateTime.fromMillisecondsSinceEpoch(0);
          final timeB = lastSeen[b.key] ?? DateTime.fromMillisecondsSinceEpoch(0);
          return timeA.compareTo(timeB);
        });
        final excess = nonStylusPointers.length - nativePointerCount;
        for (int i = 0; i < excess; i++) {
          forgetPointer(nonStylusPointers[i].key);
          prunedGhostCount++;
        }
      }
    }
  }

  void resetGestureEraser() {
    isUsingGestureEraser = false;
    eraserPositions.clear();
    lastEraserPositions.clear();
    gestureCenter = null;
    gestureLastCenter = null;
    pendingErase = null;
    lastPalmSeen = null;
  }

  void startWatchdog(bool Function() isMounted) {
    watchdog ??= Timer.periodic(const Duration(milliseconds: kWatchdogMs), (_) {
      if (!isMounted()) return;
      pruneStalePointers(force: true);
      final hadEraserState = isUsingGestureEraser || gestureCenter != null;
      if (!hasTouchDown() && hadEraserState) {
        resetGestureEraser();
        activeLayerPulse.value++;
      }
      if (pointers.isEmpty) {
        watchdog?.cancel();
        watchdog = null;
      }
    });
  }

  bool isPalm(PointerEvent e) {
    if (e.kind == PointerDeviceKind.stylus || e.kind == PointerDeviceKind.invertedStylus) return false;
    final double major = max(e.radiusMajor, e.radiusMinor);
    return major >= kPalmRadiusMajorMin || e.size >= kPalmSizeMin;
  }

  bool isEraserMode(PointerEvent event, BuildContext context) {
    if (event.kind == PointerDeviceKind.stylus) return false;

    pruneStalePointers();

    final now = DateTime.now();

    if (isUsingGestureEraser && hasTouchDown()) {
      lastPalmSeen = now;
      return true;
    }

    final freshTouches = freshTouchPointers();

    if (freshTouches.any(isPalm)) {
      lastPalmSeen = now;
      return true;
    }

    if (freshTouches.length >= kPalmClusterMinPoints) {
      final clusterPx = palmClusterRadiusMaxPx;
      double maxDist = 0.0;
      for (int i = 0; i < freshTouches.length; i++) {
        for (int j = i + 1; j < freshTouches.length; j++) {
          final d = (getCanvasLocalPos(freshTouches[i], context) - getCanvasLocalPos(freshTouches[j], context)).distance;
          if (d > maxDist) maxDist = d;
        }
      }
      if (maxDist < clusterPx) {
        lastPalmSeen = now;
        return true;
      }
    }

    if (kTwoPointerRule && freshTouches.length == 2) {
      final d = (getCanvasLocalPos(freshTouches[0], context) - getCanvasLocalPos(freshTouches[1], context)).distance;
      if (d < twoPointerPalmDistanceMaxPx) {
        lastPalmSeen = now;
        return true;
      }
    }

    if (isUsingGestureEraser) {
      resetGestureEraser();
    }

    return false;
  }

  Offset getCanvasLocalPos(PointerEvent event, BuildContext context) {
    box ??= context.findRenderObject() as RenderBox?;
    final b = box;
    Offset rawPos;
    if (b != null && b.attached) {
      rawPos = b.globalToLocal(event.position);
    } else {
      rawPos = event.localPosition;
    }

    final provider = Provider.of<WhiteboardProvider>(context, listen: false);
    return rawPos - provider.canvasPanOffset;
  }

  double gestureEraseRadius() => kStaticGestureEraserRadius;

  Offset gestureEraseCentroid(Offset fallback, BuildContext context) {
    Offset center = Offset.zero;
    int count = 0;
    for (final p in pointers.values) {
      if (!isTouchKind(p)) continue;
      center += getCanvasLocalPos(p, context);
      count++;
    }
    if (count == 0) return fallback;
    return center / count.toDouble();
  }

  void queueGestureErase(Offset center, BuildContext context, bool isMounted) {
    pendingErase = center;
    gestureCenter = center;
    if (_eraseScheduled) return;
    _eraseScheduled = true;
    SchedulerBinding.instance.scheduleFrameCallback((_) {
      _eraseScheduled = false;
      if (!isMounted) return;
      flushPendingErase(context.read<WhiteboardProvider>());
      activeLayerPulse.value++;
    });
  }

  void flushPendingErase(WhiteboardProvider provider) {
    final c = pendingErase;
    pendingErase = null;
    if (c == null || !isUsingGestureEraser) return;
    final prev = gestureLastCenter;
    if (prev != null && (c - prev).distance < kGestureMinMovePx) {
      return;
    }
    provider.partialErase(c, gestureEraseRadius(), lastPos: prev ?? c);
    gestureLastCenter = c;
  }

  void switchToEraserMode(WhiteboardProvider provider, BuildContext context, bool isMounted) {
    isUsingGestureEraser = true;

    final toDrop = activeElements.keys.where((id) {
      final p = pointers[id];
      return p == null || isTouchKind(p);
    }).toList();
    for (final id in toDrop) {
      final e = activeElements.remove(id);
      if (e is StrokeElement) e.disposeLive();
    }

    eraserPositions.clear();
    lastEraserPositions.clear();

    final c = gestureEraseCentroid(gestureCenter ?? Offset.zero, context);
    gestureCenter = c;
    gestureLastCenter = c;
    pendingErase = null;
    provider.partialErase(c, gestureEraseRadius(), lastPos: c);
    requestRepaint(isMounted);
  }
}
