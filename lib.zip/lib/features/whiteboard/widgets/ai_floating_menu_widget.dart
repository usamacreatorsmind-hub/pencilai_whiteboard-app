import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:provider/provider.dart';
import '../state/whiteboard_provider.dart';

class AiFloatingMenuWidget extends StatefulWidget {
  const AiFloatingMenuWidget({super.key});

  @override
  State<AiFloatingMenuWidget> createState() => _AiFloatingMenuWidgetState();
}

class _AiFloatingMenuWidgetState extends State<AiFloatingMenuWidget> with SingleTickerProviderStateMixin {
  bool _isExpanded = false;
  late AnimationController _animController;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<bool> _checkInternet(BuildContext context) async {
    final results = await Connectivity().checkConnectivity();
    if (!context.mounted) return false;
    if (results.contains(ConnectivityResult.none)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Color(0xFFDC2626),
          content: Text('No Internet Connection', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.all(20),
        ),
      );
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 24,
      bottom: 100,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // Expanded Menu Options (Quick Quiz, Homework, Summary)
          if (_isExpanded) ...[
            _buildMenuButton(
              title: 'Quick Quiz',
              icon: LucideIcons.sparkle,
              color: const Color(0xFF10B981), // Green sparkle
              onTap: () async {
                if (!await _checkInternet(context)) return;
                if (!context.mounted) return;
                setState(() => _isExpanded = false);
                context.read<WhiteboardProvider>().generateAiContent(type: 'Quick Quiz', isWholeDoc: false);
              },
            ),
            const SizedBox(height: 12),
            _buildMenuButton(
              title: 'Homework',
              icon: LucideIcons.sparkles,
              color: const Color(0xFF38BDF8), // Blue sparkle
              onTap: () async {
                if (!await _checkInternet(context)) return;
                if (!context.mounted) return;
                setState(() => _isExpanded = false);
                context.read<WhiteboardProvider>().generateAiContent(type: 'Homework', isWholeDoc: false);
              },
            ),
            const SizedBox(height: 12),
            _buildMenuButton(
              title: 'Summary',
              icon: LucideIcons.star,
              color: const Color(0xFFF59E0B), // Yellow sparkle
              onTap: () async {
                if (!await _checkInternet(context)) return;
                if (!context.mounted) return;
                setState(() => _isExpanded = false);
                context.read<WhiteboardProvider>().generateAiContent(type: 'Summary', isWholeDoc: false);
              },
            ),
            const SizedBox(height: 14),
          ],

          // Main Button: Circular AI Button with check for internet when clicked
          if (!_isExpanded) ...[
            AnimatedBuilder(
              animation: _animController,
              builder: (context, child) {
                return CustomPaint(
                  painter: _GradientBorderPainter(animationValue: _animController.value),
                  child: GestureDetector(
                    onTap: () async {
                      if (!await _checkInternet(context)) return;
                      if (!context.mounted) return;
                      setState(() => _isExpanded = true);
                    },
                    child: Container(
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: const Color(0xFF38BDF8).withValues(alpha: 0.4), blurRadius: 12, spreadRadius: 2)],
                      ),
                      child: Center(child: Image.asset("assets/ai.png", height: 35, width: 35)),
                    ),
                  ),
                );
              },
            ),
          ] else ...[
            // Circular Close Button with 'X'
            GestureDetector(
              onTap: () => setState(() => _isExpanded = false),
              child: Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: const Color(0xFF2563EB), width: 2),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 4))],
                ),
                child: const Center(child: Icon(LucideIcons.x, color: Colors.black, size: 24)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildMenuButton({required String title, required IconData icon, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFF2563EB), width: 1),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.3), blurRadius: 8, offset: const Offset(0, 4))],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(width: 8),
            Icon(icon, color: color, size: 16),
          ],
        ),
      ),
    );
  }
}

class _GradientBorderPainter extends CustomPainter {
  final double animationValue;

  _GradientBorderPainter({required this.animationValue});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..shader = SweepGradient(
        center: Alignment.center,
        startAngle: 0.0,
        endAngle: 3.14 * 2,
        colors: const [Color(0xFF00F5FF), Color(0xFF7B2FF7), Color(0xFFFF2E93), Color(0xFFFFE600), Color(0xFF00F5FF)],
        transform: GradientRotation(animationValue * 2 * 3.14),
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    canvas.drawCircle(Offset(size.width / 2, size.height / 2), (size.width / 2) + 2, paint);
  }

  @override
  bool shouldRepaint(covariant _GradientBorderPainter oldDelegate) {
    return oldDelegate.animationValue != animationValue;
  }
}
