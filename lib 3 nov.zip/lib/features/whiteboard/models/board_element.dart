import 'dart:math';
import 'package:flutter/material.dart';
import 'stroke_element.dart';
import 'shape_element.dart';
import 'image_element.dart';
import 'document_element.dart';
import 'text_element.dart';
import 'table_element.dart';
import 'mind_map_element.dart';
import 'chemical_element_element.dart';

abstract class BoardElement {
  final String id;
  Offset position;
  double rotation;
  double scale;
  int? docPage;

  BoardElement({
    required this.id,
    required this.position,
    this.rotation = 0.0,
    this.scale = 1.0,
    this.docPage,
  });

  Rect? _cachedBounds;

  Map<String, dynamic> toJson();

  factory BoardElement.fromJson(Map<String, dynamic> json) {
    final type = json['type'] as String;
    switch (type) {
      case 'stroke':
        return StrokeElement.fromJson(json);
      case 'shape':
        return ShapeElement.fromJson(json);
      case 'image':
        return ImageElement.fromJson(json);
      case 'document':
        return DocumentElement.fromJson(json);
      case 'text':
        return TextElement.fromJson(json);
      case 'table':
        return TableElement.fromJson(json);
      case 'mindmap':
        return MindMapElement.fromJson(json);
      case 'chemical_element':
        return ChemicalElementElement.fromJson(json);
      default:
        throw Exception('Unknown BoardElement type: $type');
    }
  }

  BoardElement copyWith({
    String? id,
    Offset? position,
    double? rotation,
    double? scale,
  });

  Rect getRawBounds() {
    if (_cachedBounds != null) return _cachedBounds!;

    Rect bounds;
    if (this is StrokeElement) {
      final points = (this as StrokeElement).points;
      if (points.isEmpty) {
        bounds = Rect.fromLTWH(position.dx, position.dy, 0, 0);
      } else {
        double minX = points[0].dx;
        double maxX = points[0].dx;
        double minY = points[0].dy;
        double maxY = points[0].dy;
        for (var p in points) {
          minX = min(minX, p.dx);
          maxX = max(maxX, p.dx);
          minY = min(minY, p.dy);
          maxY = max(maxY, p.dy);
        }
        bounds = Rect.fromLTRB(minX, minY, maxX, maxY);
      }
    } else if (this is ShapeElement) {
      final shape = this as ShapeElement;
      bounds = Rect.fromPoints(shape.position, shape.endPoint);
    } else if (this is ImageElement) {
      final img = this as ImageElement;
      bounds = Rect.fromLTWH(
        img.position.dx,
        img.position.dy,
        img.size.width,
        img.size.height,
      );
    } else if (this is DocumentElement) {
      final doc = this as DocumentElement;
      bounds = Rect.fromLTWH(
        doc.position.dx,
        doc.position.dy,
        doc.size.width,
        doc.size.height,
      );
    } else if (this is TextElement) {
      final txt = this as TextElement;
      if (txt.size.width <= 0 || txt.size.height <= 0) {
        txt.size = txt.computeActualSize();
      }
      bounds = Rect.fromLTWH(
        txt.position.dx,
        txt.position.dy,
        txt.size.width,
        txt.size.height,
      );
    } else if (this is TableElement) {
      final tbl = this as TableElement;
      bounds = Rect.fromLTWH(
        tbl.position.dx,
        tbl.position.dy,
        tbl.size.width,
        tbl.size.height,
      );
    } else if (this is MindMapElement) {
      final mm = this as MindMapElement;
      bounds = Rect.fromLTWH(
        mm.position.dx,
        mm.position.dy,
        mm.size.width,
        mm.size.height,
      );
    } else if (this is ChemicalElementElement) {
      final ce = this as ChemicalElementElement;
      bounds = Rect.fromLTWH(
        ce.position.dx,
        ce.position.dy,
        ce.size.width,
        ce.size.height,
      );
    } else {
      bounds = Rect.fromLTWH(position.dx, position.dy, 100, 100);
    }


    _cachedBounds = bounds;
    return bounds;
  }

  void invalidateBounds() {
    _cachedBounds = null;
  }

  void invalidatePath() {
    // Subclasses like StrokeElement will override this
  }
}
